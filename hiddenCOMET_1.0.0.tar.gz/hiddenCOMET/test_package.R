library(hiddenCOMET)

# Test that the main functions are available
cat("Testing package functions:\n")
cat("build_G function:", exists("build_G"), "\n")
cat("estimate_B_ls function:", exists("estimate_B_ls"), "\n")
cat("estimate_B_mle function:", exists("estimate_B_mle"), "\n")
cat("fit_G_given_p0 function:", exists("fit_G_given_p0"), "\n")

# Test a simple function call
states <- c("E", "M", "T")
rates <- c(0.1, 0.2, 0.15, 0.25)
G <- build_G(rates, states)
cat("Generator matrix G:\n")
print(G)

cat("Package installation successful!\n")
